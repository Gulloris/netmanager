# Upgrade Plan: isp-manager (20260605195032)

- **Generated**: 2026-06-05 19:50:32
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 25.0.3: C:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot\bin (target runtime)
- JDK 21: not available (baseline verification skipped)

**Build Tools**
- Maven 3.9.16: C:\Users\Clayton\.maven\maven-3.9.16\bin
- Maven 3.9.16: C:\Maven\bin

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260605195032
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency    | Current | Min Compatible | Why Incompatible |
| ------------------------ | ------- | -------------- | ---------------------------------------------- |
| Java                     | 25      | 25             | User requested latest LTS runtime              |
| Spring Boot              | 3.2.0   | 3.2.0          | No Spring Boot upgrade required for Java 25    |
| Maven                    | 3.9.16  | 3.9.0          | Build tool available and compatible with Java 25 |
| maven-compiler-plugin    | 3.11.0  | 3.11.0         | Recommended for Java 25 source/target handling |
| Lombok                   | 1.18.30 | 1.18.30        | No change required                              |

## Derived Upgrades

- None. The project is already configured to compile with Java 25 in `pom.xml`.
- Documentation needs alignment to the current runtime and Maven support level.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version | 25 | none | 25 | Already matches latest LTS target |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None | N/A | N/A | N/A | No source changes required for Java 25 runtime upgrade |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| README.md | Stack description | Java 17 + Spring Boot 3 + Thymeleaf + PostgreSQL | Update to Java 25 + Spring Boot 3 + Thymeleaf + PostgreSQL | Reflect current runtime target |
| README.md | Local prerequisites | Java 17+ | Java 25+ | Align local developer requirements with build config |
| README.md | Maven version | Maven 3.6+ | Maven 3.9+ | Use an environment that is compatible with Java 25 and current Maven availability |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None | N/A | N/A | No CI/CD files detected that require Java version updates |

### Risks & Warnings

- **Baseline JDK unavailable**: Java 21 is not installed locally. Baseline verification using the original project runtime will be skipped and only Java 25 validation will be performed.
- **Documentation drift**: README still claims Java 17+ and Maven 3.6+. This must be updated to reduce confusion for developers and deployment automation.
- **Runtime compatibility verification**: Even though the project is already set to Java 25, a full `mvn clean test` run is required to confirm there are no hidden incompatibilities with the target runtime.

## Upgrade Steps

- Step 1: Verify target toolchain availability
  - **Rationale**: Confirm Java 25 and Maven are present before making changes or validation attempts.
  - **Changes to Make**: None; confirm environment and tool paths.
  - **Verification**: `java --version && mvn -v` using Java 25 and Maven 3.9.16

- Step 2: Align documentation with the current Java runtime
  - **Rationale**: The project already targets Java 25, so the remaining upgrade work is to keep developer-facing documentation accurate.
  - **Changes to Make**: Update `README.md` stack and prerequisites text to Java 25+ and Maven 3.9+.
  - **Verification**: `git diff` equivalent review and ensure no build-impacting docs changes are introduced.

- Step 3: CVE validation and fix
  - **Rationale**: Ensure direct dependencies are not exposing known vulnerabilities after runtime upgrade verification.
  - **Changes to Make**: Run CVE scan on direct Java dependencies and fix any reported issues by updating versions if needed.
  - **Verification**: `mvn clean test-compile -q` after applying any fixes, plus re-scan with `#appmod-validate-cves-for-java`.

- Step 4: Final validation under Java 25
  - **Rationale**: Confirm the project compiles and all tests pass on the target runtime.
  - **Changes to Make**: None beyond validation, unless test failures require fixes.
  - **Verification**: `mvn clean test -q` using Java 25 and Maven 3.9.16
