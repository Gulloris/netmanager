# Upgrade Plan: isp-manager (20260605192045)

- **Generated**: 2026-06-05 19:20 (local)
- **HEAD Branch**: master
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 25: C:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot\bin (required by Step 6)
- JDK 26: C:\Program Files\Java\jdk-26.0.1\bin (installed, not required)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (no system Maven detected; project has no `mvnw` wrapper)


## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

- Preserve current Spring Boot 3.2.x behavior unless incompatibility requires plugin changes.

## Options

- Working branch: appmod/java-upgrade-20260605192045
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java: upgrade from 17 → 25 (latest LTS)

## Technology Stack

| Technology/Dependency    | Current | Min Compatible | Why Incompatible                               |
| ------------------------ | ------- | -------------- | ---------------------------------------------- |
| Java                     | 17      | 25             | User requested upgrade to latest LTS           |
| Spring Boot              | 3.2.0   | 3.2.x / 3.3.x  | Spring Boot 3.2.x supports modern JDKs; verify compatibility (no immediate change required) |
| Maven (system)           | N/A     | 3.9+ (recommended) | No system Maven detected; Maven 3.9+ recommended for Java 21+; use wrapper or install system Maven |
| maven-compiler-plugin    | (not declared) | 3.11.0+    | Recommended for newer Java targets; add if missing |


## Derived Upgrades

- Install or enable Maven 3.9+ (or add `mvnw`) so builds can be executed with JDK 25.
- Add or pin `maven-compiler-plugin` 3.11+ if compilation issues appear (plugin not explicitly configured).


## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version property | 17 | upgrade | 25 | User requested; compile with JDK 25


### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| (none detected) | - | - | None planned | Spring Boot 3.2.0 codebase appears Java-25 compatible; adjust only if compilation/runtime errors appear (reflection, illegal access) |


### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| pom.xml | `<properties><java.version>` | 17 | 25 | Compile with target JDK


### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|-----------------|
| Procfile | root | (runtime unspecified) | No immediate change; if CI specifies JDK version, update to 25 |


### Risks & Warnings

- **No Maven detected**: System Maven missing; plan includes installing Maven or adding a wrapper before running builds.
- **Runtime reflection / encapsulation issues**: JDK 17→25 increases strong encapsulation; code using `setAccessible` or internal APIs may compile but fail at runtime. Mitigation: run full test suite and fix failures; add `--add-opens` temporary flags only if unavoidable.
- **Untracked repo files**: Many project files are untracked. We'll stash/create branch before committing changes.


## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Ensure required JDKs and build tool are available for iteration and verification
  - **Changes to Make**: Install/ensure JDK 25 present (detected); install system Maven 3.9+ or add Maven Wrapper
  - **Verification**: `mvn -v` or `.
` using wrapper; expected: Maven 3.9+ and `java -version` shows 25

- Step 2: Setup Baseline
  - **Rationale**: Capture current compilation/test baseline on Java 17 (optional if base JDK missing)
  - **Changes to Make**: Run `mvn clean test-compile` and `mvn test` using current Java (17) if available
  - **Verification**: `mvn -DskipTests=false test` (JDK path: current java); record test pass-rate

- Step 3: Update Build Files (Java target)
  - **Rationale**: Primary change — bump `<java.version>` to 25 and ensure compiler plugin supports target
  - **Changes to Make**: Update `<properties><java.version>` in `pom.xml` from 17 → 25; add `maven-compiler-plugin` 3.11.0 config if needed
  - **Verification**: `mvn clean test-compile -DskipTests=true` with JDK 25

- Step 4: Compile & Fix Source Issues
  - **Rationale**: Resolve any compilation issues triggered by newer JDK
  - **Changes to Make**: Apply minimal code changes for illegal access, removed APIs, or other compilation errors; prefer small targeted fixes
  - **Verification**: `mvn clean test-compile` (JDK 25)

- Step 5: Run Full Test Suite
  - **Rationale**: Ensure behavioral compatibility; required by success criteria
  - **Changes to Make**: Fix failing tests until 100% pass (or match baseline if baseline recorded)
  - **Verification**: `mvn test` (JDK 25) — 100% pass required (see options)

- Step 6: CVE scan & fixes
  - **Rationale**: Validate direct dependencies for known CVEs and fix
  - **Changes to Make**: Use dependency:list to extract direct deps, run CVE scan, upgrade direct deps as needed
  - **Verification**: `mvn clean test-compile` and re-scan CVEs

- Step 7: Final Validation & Summary
  - **Rationale**: Confirm all goals met and generate summary
  - **Changes to Make**: Produce `summary.md`, update docs where required, commit changes to working branch
  - **Verification**: `mvn clean verify` (JDK 25), tests 100% pass



Please review this plan. Once you confirm, I will proceed to create the working branch, stash uncommitted files, and begin Step 1 (install/enable Maven or add `mvnw`, then update `pom.xml`).
